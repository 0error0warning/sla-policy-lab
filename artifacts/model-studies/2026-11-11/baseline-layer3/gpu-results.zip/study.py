"""Fixed-experience baseline comparison and held-out layer-3 interventions."""

import argparse
import json
from pathlib import Path

import numpy as np

from mechanisms import observe
from protocol import (ARMS, ORDERS, PROBE_ORDERS, World, policy, prompt, request,
                      returns, reward, sample_action, settle, write)
from run_gpu import Actor, optimize, tensor_hash


NEW_SEEDS = (62101, 62102, 62103, 62104)


def make_panel():
    return [dict(health=health, visible=visible, frame=frame, order=list(order),
                 partner='P17', request=request(frame, 4, 2))
            for health, visible in ((300., True), (2., True), (300., False))
            for frame in (0, 1) for order in ORDERS]


def bodily_buffer(actor, tape, health):
    rows = []
    for transition in tape['trace']:
        tokens = actor.encode(prompt(transition['partner'], transition['request'], 300.,
                                     transition['order'], False))
        after, _ = settle(health, transition['action'], transition['accepted'], transition['noise'])
        assert after > 0
        full, _ = reward(health, after, transition['action'], transition['accepted'])
        common, _ = reward(health, after, transition['action'], transition['accepted'], False)
        label = transition['order'].index(transition['action'])
        rows.append(dict(turn=transition['turn'], input_token_ids=tokens, label_index=label,
                         health_before=health, health_after=after, reward_body=full,
                         reward_common=common))
        health = after
    logits, _ = observe(actor, [row['input_token_ids'] for row in rows])
    probabilities = policy(logits)
    for i, row in enumerate(rows):
        row['old_log_probability'] = float(np.log(probabilities[i, row['label_index']]))
    return rows


def patch_forward(actor, tokens, center, direction, donor=None, random=None, restore=False):
    """Ablate one projection at layer 3, or exchange the paired projection."""
    torch = actor.torch
    results = []
    for start in range(0, len(tokens), 4):
        batch = tokens[start:start+4]
        positions = torch.tensor([len(t)-1 for t in batch], device='cuda')
        indices = torch.arange(len(batch), device='cuda')
        u = torch.as_tensor(direction, device='cuda')
        target = torch.as_tensor(center, device='cuda')
        if donor is not None:
            target = torch.as_tensor(donor[start:start+len(batch)], device='cuda')
        destination = u if random is None else torch.as_tensor(random, device='cuda')

        def hook(module, args, output):
            state = output[0] if isinstance(output, tuple) else output
            values = state[indices, positions].float()
            shift = (target-values) @ u
            changed_values = values+shift[:, None]*destination
            if restore:
                changed_values = changed_values-shift[:, None]*destination
            changed = state.clone()
            changed[indices, positions] = changed_values.to(state.dtype)
            return (changed, *output[1:]) if isinstance(output, tuple) else changed

        handle = actor.base.model.language_model.layers[3].register_forward_hook(hook)
        try:
            with torch.no_grad():
                results.append(actor.logits(batch).cpu().numpy())
        finally:
            handle.remove()
    return np.concatenate(results)


def run(root):
    from safetensors.torch import load_file, save_file

    output = root/'output'
    output.mkdir(exist_ok=False)
    status = dict(stage='initializing', completed_cases=0, total_cases=32, optimizer_steps=0)
    def progress(**values):
        status.update(values)
        write(output/'status.json', status)
    actor = Actor(root, output, progress)
    tapes = json.loads((root/'tapes.json').read_bytes())
    assert len(tapes) == 4
    # New data are collected by the unchanged frozen policy before any updates.
    for index, seed in enumerate(NEW_SEEDS):
        world = World(seed, index % 2, f'new-{seed}')
        trace = []
        for transition in world.items[:8]:
            tokens = actor.encode(prompt(transition['partner'], transition['request'], world.health,
                                         transition['order'], True))
            logits, _ = observe(actor, [tokens])
            action, label, uniform = sample_action(policy(logits)[0], transition['order'],
                                                   seed, transition['turn'])
            row = world.step(world.encounter_id(), action)
            row.update(source_logits=logits[0].tolist(), source_tokens=tokens,
                       source_label=label, source_choice_uniform=uniform)
            trace.append(row)
        tapes.append(dict(seed=seed, mapping=index % 2, low_start=90., trace=trace))
    write(output/'tapes.json', tapes)
    buffers = {(tape['seed'], damage): bodily_buffer(actor, tape, health)
               for tape in tapes for damage, health in (('light', 300.), ('heavy', 90.))}
    old_seeds = [t['seed'] for t in tapes[:4]]
    discounted = {key: returns([row['reward_body'] for row in buffer], .97)
                  for key, buffer in buffers.items()}
    baselines = {}
    for tape in tapes:
        for damage in ('light', 'heavy'):
            sources = [s for s in old_seeds if s != tape['seed']]
            baselines[tape['seed'], damage] = np.mean([discounted[s, damage] for s in sources], axis=0)
    write(output/'baseline-sources.json', [
        dict(seed=seed, damage=damage, sources=[s for s in old_seeds if s != seed],
             baseline=value.tolist()) for (seed, damage), value in baselines.items()])
    panel = make_panel()
    tokens = [actor.encode(prompt(row['partner'], row['request'], row['health'],
                                 row['order'], row['visible'])) for row in panel]
    untrained, _ = observe(actor, tokens)
    write(output/'panel.json', panel)
    write(output/'initial.json', untrained.tolist())
    # Preserve the exact condition order for paired repeatability.
    for tape in tapes:
        seed = tape['seed']
        for method in ('zero', 'independent'):
            for damage in ('light', 'heavy'):
                actor.reset('early')
                buffer = buffers[seed, damage]
                opt = actor.torch.optim.AdamW(actor.parameters['early'].values(),
                                              lr=.0001, weight_decay=0.)
                baseline = np.zeros(8) if method == 'zero' else baselines[seed, damage]
                updates = []
                doses = {}
                for dose, epochs in ((8, 4), (24, 8)):
                    updates.append(optimize(actor, opt, buffer, dict(ARMS['body'], epochs=epochs),
                                            baseline.copy(), seed, 1, lambda **_: None))
                    # Training cases use the same batch layout before and after updates.
                    training_logits, _ = observe(actor, [r['input_token_ids'] for r in buffer])
                    evaluation, feature = observe(actor, tokens, (3,))
                    doses[str(dose)] = dict(logits=evaluation.tolist(),
                                           training_logits=training_logits.tolist())
                name = f'{seed}-{method}-{damage}'
                state = actor.snapshot()
                save_file(state, str(output/f'{name}.safetensors'))
                np.savez_compressed(output/f'{name}-features.npz', layer3=feature['3'])
                write(output/f'{name}.json', dict(seed=seed, method=method, damage=damage,
                    buffer=buffer, baseline=baseline.tolist(), updates=updates, doses=doses,
                    adapter_sha256=tensor_hash(state.items())))
                status['completed_cases'] += 1
                status['optimizer_steps'] += 24
                progress(stage='training', case=name)
    selected_indices = [i for i, row in enumerate(panel) if tuple(row['order']) in PROBE_ORDERS]
    patch_tokens = [tokens[i] for i in selected_indices]
    write(output/'patch-panel-indices.json', selected_indices)
    directions = {}
    for method in ('zero', 'independent'):
        light, heavy = [], []
        for seed in old_seeds:
            for condition, values in (('light', light), ('heavy', heavy)):
                with np.load(output/f'{seed}-{method}-{condition}-features.npz') as f:
                    values.append(f['layer3'][-48:])
        light, heavy = np.concatenate(light), np.concatenate(heavy)
        direction = (heavy-light).mean(axis=0)
        direction /= np.linalg.norm(direction)
        center = (heavy.mean(axis=0)+light.mean(axis=0))/2
        controls = []
        for index in range(3):
            vector = np.random.default_rng(621030+index).standard_normal(len(direction)).astype(np.float32)
            vector -= (vector @ direction)*direction
            controls.append(vector/np.linalg.norm(vector))
        np.savez_compressed(output/f'{method}-readout.npz', direction=direction, center=center,
                            random_directions=controls)
        directions[method] = (direction, center, controls)
    for seed in NEW_SEEDS:
        for method in ('zero', 'independent'):
            direction, center, controls = directions[method]
            for damage, other in (('light', 'heavy'), ('heavy', 'light')):
                name = f'{seed}-{method}-{damage}'
                actor.install(load_file(str(output/f'{name}.safetensors')))
                base, native = observe(actor, patch_tokens, (3,))
                other_state = load_file(str(output/f'{seed}-{method}-{other}.safetensors'))
                actor.install(other_state)
                _, donor_features = observe(actor, patch_tokens, (3,))
                actor.install(load_file(str(output/f'{name}.safetensors')))
                changes = dict(ablate=patch_forward(actor, patch_tokens, center, direction),
                    restore=patch_forward(actor, patch_tokens, center, direction, restore=True),
                    swap=patch_forward(actor, patch_tokens, center, direction,
                                       donor=donor_features['3']))
                for index, vector in enumerate(controls):
                    changes[f'random{index}'] = patch_forward(actor, patch_tokens, center, direction,
                                                             random=vector)
                error = float(np.abs(policy(changes['restore'])-policy(base)).max())
                assert error < .002
                write(output/f'{name}-patch.json', dict(base=base.tolist(),
                    logits={key: value.tolist() for key, value in changes.items()},
                    restore_probability_error=error))
                progress(stage='patching', case=name)
    actor.reset('early')
    restored, _ = observe(actor, tokens[:4])
    assert np.array_equal(restored, untrained[:4])
    actor.verify_base()
    progress(stage='complete', base_unchanged=True, base_sha256=actor.base_hash)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    run(parser.parse_args().root)
