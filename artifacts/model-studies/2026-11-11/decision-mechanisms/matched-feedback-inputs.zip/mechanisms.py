"""Read-only Qwen adapter and last-token residual interventions."""

import argparse
import json
from pathlib import Path

import numpy as np

from protocol import policy, probes, prompt, write
from run_gpu import Actor, tensor_hash


LAYERS = (0, 1, 2, 3, 7, 15, 23, 31)


def panel():
    return [row for row in probes() if row['partner'] != 'P86'
            and row['health'] in (2., 300.) and row['split'] in ('train', 'joint')]


def observe(actor, tokens, layers=(), replacement=None):
    torch = actor.torch
    modules = actor.base.model.language_model.layers
    scores = []
    features = {layer: [] for layer in layers}
    for start in range(0, len(tokens), 4):
        batch = tokens[start:start+4]
        positions = torch.tensor([len(t)-1 for t in batch], device='cuda')
        indices = torch.arange(len(batch), device='cuda')

        def hook(layer):
            def intervene(module, args, output):
                state = output[0] if isinstance(output, tuple) else output
                last = state[indices, positions]
                if layer in features:
                    features[layer].append(last.float().cpu().numpy())
                if replacement is None or replacement[0] != layer:
                    return None
                donor = replacement[1][start:start+len(batch)]
                values = last.float()
                if len(replacement) == 2:
                    new = torch.as_tensor(donor, device='cuda', dtype=state.dtype)
                else:
                    direction, destination = replacement[2:]
                    u = torch.as_tensor(direction, device='cuda', dtype=torch.float32)
                    v = torch.as_tensor(destination, device='cuda', dtype=torch.float32)
                    shift = (torch.as_tensor(donor, device='cuda')-values) @ u
                    new = (values+shift[:, None]*v).to(state.dtype)
                changed = state.clone()
                changed[indices, positions] = new
                return (changed, *output[1:]) if isinstance(output, tuple) else changed
            return intervene

        selected = set(layers)
        if replacement is not None:
            selected.add(replacement[0])
        handles = [modules[layer].register_forward_hook(hook(layer)) for layer in selected]
        try:
            with torch.no_grad():
                scores.append(actor.logits(batch).cpu().numpy())
        finally:
            for handle in handles:
                handle.remove()
    return np.concatenate(scores), {str(i): np.concatenate(v) for i, v in features.items()}


def mask_weights(initial, trained, disabled):
    return {name: (initial[name] if any(f'.layers.{i}.' in name for i in disabled) else value)
            for name, value in trained.items()}


def health_interventions(actor, tokens, features, rows, comparisons):
    layer = 15
    states = features[str(layer)]
    contrast = np.array([states[j]-states[i] for i, j in comparisons
                         if rows[i]['split'] == 'train'])
    direction = contrast.mean(axis=0)
    direction /= np.linalg.norm(direction)
    control = np.random.default_rng(78104).standard_normal(len(direction)).astype(np.float32)
    control -= (control @ direction)*direction
    control /= np.linalg.norm(control)
    donors = states.copy()
    for low, high in comparisons:
        donors[low] = states[high]
    for name, patch in {
        'health_full': (layer, donors),
        'health_projection': (layer, donors, direction, direction),
        'health_random': (layer, donors, direction, control),
    }.items():
        yield name, observe(actor, tokens, replacement=patch)[0]


def run(root):
    from safetensors.torch import load_file

    out = root/'output'
    out.mkdir()
    def progress(**data):
        write(out/'status.json', data)
    actor = Actor(root, out, progress)
    initial = actor.snapshot()
    rows = panel()
    tokens = [actor.encode(prompt(r['partner'], r['request'], r['health'], r['order'])) for r in rows]
    by_context = {(r['partner'], r['frame'], r['split'], tuple(r['order']), r['health']): i
                  for i, r in enumerate(rows)}
    pairs = [(i, by_context[r['partner'], r['frame'], r['split'], tuple(r['order']), 300.])
             for i, r in enumerate(rows) if r['health'] == 2.]
    manifest = json.loads((root/'source.json').read_bytes())
    write(out/'panel.json', rows)
    base, base_features = observe(actor, tokens, LAYERS)
    sham, _ = observe(actor, tokens, replacement=(15, base_features['15']))
    assert np.array_equal(base, sham)
    def save(name, logits, features):
        np.savez_compressed(out/f'{name}.npz', logits=logits,
                            **{f'layer_{i}': x.astype(np.float16) for i, x in features.items()})
    save('frozen', base, base_features)
    write(out/'frozen-interventions.json', {n: z.tolist() for n, z in
                                          health_interventions(actor, tokens, base_features, rows, pairs)})
    write(out/'tokens.json', tokens)
    for count, row in enumerate(manifest, 1):
        name = row['id']
        trained = load_file(str(root/f'{name}.safetensors'))
        assert set(trained) == set(initial)
        actor.install(trained)
        full, features = observe(actor, tokens, LAYERS)
        core = row['core']
        old_tokens = [actor.encode(prompt(r['partner'], r['request'], r['health'], r['order']))
                      for r in core]
        old_scores, _ = observe(actor, old_tokens)
        replay_error = float(np.abs(policy(old_scores)-policy(row['core_logits'])).max())
        assert replay_error < .02, (name, replay_error)
        interventions = {}
        if row['arm'] == 'body':
            for n, z in health_interventions(actor, tokens, features, rows, pairs):
                interventions[n] = z.tolist()
            for layer in (3, 15):
                z, _ = observe(actor, tokens, replacement=(layer, base_features[str(layer)]))
                interventions[f'remove_residual_{layer}'] = z.tolist()
            for removed in ((0, 1), (2, 3)):
                actor.install(mask_weights(initial, trained, removed))
                z, _ = observe(actor, tokens)
                interventions[f'reset_layers_{removed[0]}_{removed[1]}'] = z.tolist()
            actor.install(initial)
            for layer in (3, 15):
                z, _ = observe(actor, tokens, replacement=(layer, features[str(layer)]))
                interventions[f'transfer_residual_{layer}'] = z.tolist()
        actor.install(initial)
        restored, _ = observe(actor, tokens[:4])
        assert np.array_equal(restored, base[:4])
        save(name, full, features)
        write(out/f'{name}.json', dict(logits=full.tolist(), interventions=interventions,
                                     adapter_sha256=tensor_hash(trained.items()), replay_error=replay_error))
        progress(stage='probes', complete=count, total=len(manifest))
    actor.verify_base()
    write(out/'source.json', manifest)
    progress(stage='complete', complete=len(manifest), total=len(manifest),
             base_sha256=actor.base_hash, sham_exact=True, gpu=actor.torch.cuda.get_device_name())


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    run(parser.parse_args().root)
