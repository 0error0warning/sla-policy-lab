"""Matched eight-encounter replay with scalar feedback interventions."""

import argparse
import json
from pathlib import Path

import numpy as np

from mechanisms import observe
from protocol import ARMS, ORDERS, PROBE_ORDERS, policy, prompt, request, reward, settle, write
from run_gpu import Actor, optimize, tensor_hash


def run(root):
    from safetensors.torch import save_file

    out = root/'output'
    out.mkdir()
    def progress(**data):
        write(out/'status.json', data)
    actor = Actor(root, out, progress)
    torch = actor.torch
    tapes = json.loads((root/'tapes.json').read_bytes())
    rows = [dict(health=h, visible=visible, frame=f, order=list(order), partner='P17',
                 request=request(f, 4, 2))
            for h, visible in ((300., True), (2., True), (300., False))
            for f in (0, 1) for order in ORDERS]
    eval_tokens = [actor.encode(prompt(r['partner'], r['request'], r['health'], r['order'], r['visible'])) for r in rows]
    hidden = eval_tokens[-48:]
    feature_indices = [frame*24+ORDERS.index(order) for frame in (0, 1) for order in PROBE_ORDERS]
    feature_tokens = [hidden[i] for i in feature_indices]
    init_logits, _ = observe(actor, eval_tokens)
    write(out/'panel.json', rows)
    write(out/'initial.json', init_logits.tolist())
    write(out/'tapes.json', tapes)
    initial = actor.snapshot()
    adapters = {}
    features = {}
    for tape in tapes:
        seed = tape['seed']
        tokens = [actor.encode(prompt(r['partner'], r['request'], 300., r['order'], False))
                  for r in tape['trace']]
        source_logits, _ = observe(actor, tokens)
        source_policy = policy(source_logits)
        buffers = {}
        for condition, starting in (('light', 300.), ('heavy', tape['low_start'])):
            health = starting
            rows_for_condition = []
            for i, (transition, tok) in enumerate(zip(tape['trace'], tokens)):
                action = transition['action']
                accepted = transition['accepted']
                after, _ = settle(health, action, accepted, transition['noise'])
                assert after > 0.
                common, _ = reward(health, after, action, accepted, False)
                full, _ = reward(health, after, action, accepted, True)
                label = transition['order'].index(action)
                rows_for_condition.append(dict(turn=i+1, input_token_ids=tok, label_index=label,
                    old_log_probability=float(np.log(source_policy[i, label])),
                    reward_common=common, reward_body=full, damage=health-after,
                    health_before=health, health_after=after))
                health = after
            buffers[condition] = rows_for_condition
        permutation = tape['damage_permutation']
        heavy = buffers['heavy']
        buffers['shuffled'] = [dict(row, reward_body=row['reward_common']-.15*heavy[permutation[i]]['damage'])
                               for i, row in enumerate(heavy)]
        buffers['social'] = heavy
        for condition, buffer in buffers.items():
            actor.install(initial)
            opt = torch.optim.AdamW(actor.parameters['early'].values(), lr=.0001, weight_decay=0.)
            arm = dict(ARMS['body'], body_reward=(condition != 'social'))
            baseline = np.zeros(8)
            update1 = optimize(actor, opt, buffer, arm, baseline, seed, 1, lambda **_: None)
            intermediate, _ = observe(actor, eval_tokens)
            # Keep the same frozen reference, batch, and zero baseline for the longer replay.
            update2 = optimize(actor, opt, buffer, dict(arm, epochs=8), np.zeros(8),
                               seed, 1, lambda **_: None)
            end, _ = observe(actor, eval_tokens)
            feature_logits, sampled = observe(actor, feature_tokens, (3, 15, 31))
            name = f'{seed}-{condition}'
            state = actor.snapshot()
            save_file(state, str(out/f'{name}.safetensors'))
            features[name] = sampled
            if condition in ('heavy', 'light'):
                adapters[name] = state
            np.savez_compressed(out/f'{name}-features.npz', **{k: v.astype(np.float16) for k, v in sampled.items()})
            write(out/f'{name}.json', dict(seed=seed, condition=condition, buffer=buffer,
                 intermediate_indices=list(range(len(rows))), intermediate=intermediate.tolist(),
                 logits=end.tolist(), end_matched=end.tolist(), feature_logits=feature_logits.tolist(),
                 updates=[update1, update2], adapter_sha256=tensor_hash(state.items())))
            progress(stage='feedback', seed=seed, condition=condition)
        actor.install(initial)
    # Infer the damage-history direction from other seeds and intervene on each held-out life.
    for tape in tapes:
        seed = tape['seed']
        others = [t['seed'] for t in tapes if t['seed'] != seed]
        direction = np.concatenate([features[f'{s}-heavy']['15']-features[f'{s}-light']['15']
                                    for s in others]).mean(axis=0)
        direction /= np.linalg.norm(direction)
        random = np.random.default_rng(611812).standard_normal(len(direction)).astype(np.float32)
        random -= (random @ direction)*direction
        random /= np.linalg.norm(random)
        result = {}
        for receiving, donating in (('heavy', 'light'), ('light', 'heavy')):
            actor.install(adapters[f'{seed}-{receiving}'])
            donor = features[f'{seed}-{donating}']['15']
            result[receiving] = {}
            for name, patch in [('full', (15, donor)), ('direction', (15, donor, direction, direction)),
                                ('random', (15, donor, direction, random))]:
                logits, _ = observe(actor, feature_tokens, replacement=patch)
                result[receiving][name] = logits.tolist()
        write(out/f'{seed}-patch.json', dict(indices=[len(rows)-48+i for i in feature_indices], results=result))
    actor.install(initial)
    restored, _ = observe(actor, eval_tokens[:4])
    assert np.array_equal(init_logits[:4], restored)
    actor.verify_base()
    progress(stage='complete', base_sha256=actor.base_hash, tapes=len(tapes), optimizer_steps=24*4*len(tapes))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    run(parser.parse_args().root)
