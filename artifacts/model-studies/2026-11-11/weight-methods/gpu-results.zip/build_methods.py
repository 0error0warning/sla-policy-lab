"""Create paired, two-partner histories from the fixed earlier encounter schedules."""

import argparse
from collections import defaultdict
import json
from pathlib import Path

import numpy as np

from protocol import Config, World, canonical


STYLES = ("appeal", "exchange", "direct")
ANCHOR = "P53"


def build(prior):
    config = prior["life"]["config"] | {"horizon": 60}
    blocks = []
    for block in prior["life"]["blocks"]:
        seed, focus = block["seed"], block["partner"]
        rng = np.random.default_rng(seed + 3181)
        old = [(style, outcome) for style, values in zip(STYLES, [[False]*4, [True]*4, [False,True]*2], strict=True)
               for outcome in values] + [("answer", None)]*3
        old = [(ANCHOR,*old[i]) for i in rng.permutation(len(old))]
        histories = []
        for source in block["histories"]:
            world = World(Config(**config), seed)
            schedule = old + [(focus,r["action"],r["accepted"]) for r in source["trace"]]
            trace, phases = [], []
            counts = defaultdict(lambda: {s:[0,0] for s in STYLES})
            for i,(partner,style,outcome) in enumerate(schedule):
                before = world.observation()
                draw = world.events[i,1]
                try:
                    if outcome is not None:
                        world.events[i,1] = 0. if outcome else 1.
                    after,reward,done,info = world.step(0 if style=="answer" else 2)
                finally:
                    world.events[i,1] = draw
                assert info["protection_accepted"] == outcome and after["alive"]
                assert done == (i==59)
                if outcome is not None:
                    counts[partner][style][0] += int(outcome)
                    counts[partner][style][1] += 1
                trace.append(dict(turn=i+1,partner=partner,style=style,accepted=outcome,before=before,after=after,reward=reward))
                if (i+1)%15==0:
                    phases.append(dict(turn=i+1,active=partner,
                        counts={p:{s:list(v) for s,v in group.items()} for p,group in counts.items()}))
            histories.append(dict(trace=trace,phases=phases))
        a,b = (h["trace"] for h in histories)
        assert a[:15] == b[:15]
        assert all((x["partner"],x["style"],x["before"]["load"])==(y["partner"],y["style"],y["before"]["load"]) for x,y in zip(a,b))
        assert all(sum(r["accepted"] is True for r in a[:end]) == sum(r["accepted"] is True for r in b[:end])
                   for end in (15,30,45,60))
        blocks.append(dict(id=block["id"],seed=seed,focus=focus,histories=histories))
    return dict(schema="sla-weight-methods-v1",probes=prior["probes"],actions=prior["actions"],
        blocks=blocks,anchor=ANCHOR,config=config,layers=[0,1,2,3],initial_seed=61005,
        learning_rate=.0001,steps_per_phase=24,batch_size=6,
        ridge_lambda=.02,edit_anchor_weight=4.,fast_lambda=.15,fast_outcome_logit=float(np.log(5.)),
        methods=["lora","ia3","edit","edit_anchored","fast","frozen_history","frozen","beta"])


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("prior",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    args.output.write_bytes(canonical(build(json.loads(args.prior.read_bytes()))))
