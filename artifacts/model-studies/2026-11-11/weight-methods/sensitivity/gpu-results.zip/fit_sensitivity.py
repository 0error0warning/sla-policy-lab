"""Compare shared and partner-routed weight updates on paired life histories."""

from copy import deepcopy
import re
import time

import numpy as np

from train import read, tensor_hash, write
from weight_math import ridge_edit


STYLES = ("appeal","exchange","direct")


def run_methods(spec_path, protocol, base, model, initial, tokenizer, output, status):
    import torch
    import torch.nn.functional as F
    from peft import LoraConfig
    from safetensors.torch import save_file

    spec = read(spec_path)
    assert spec["schema"]=="sla-weight-methods-v1"
    cfg = protocol["training_config"]
    rows = [r | {"split":split} for split in ("train","heldout") for r in spec["probes"][split]]
    assert len(rows)==72
    train_ids = [i for i,r in enumerate(rows) if r["split"]=="train"]
    by_partner = {p:[i for i in train_ids if rows[i]["partner"]==p] for p in sorted({r["partner"] for r in rows})}
    assert all(len(indices)==6 for indices in by_partner.values())
    labels = [tokenizer.encode(a,add_special_tokens=False) for a in spec["actions"]]
    assert labels==[[10024],[45427]]
    tokens = torch.tensor([a[0] for a in labels],device="cuda")
    head = base.lm_head
    assert head.bias is None and head.weight.dtype==torch.bfloat16
    tied = head.weight.data_ptr()==base.model.language_model.embed_tokens.weight.data_ptr()
    if tied:
        head.weight = torch.nn.Parameter(head.weight.detach().clone(),requires_grad=False)
    head_start = head.weight[tokens].detach().clone()
    model.eval()

    def prepare(messages):
        text = tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,enable_thinking=False)
        prefix = tokenizer.encode(text,add_special_tokens=False)
        for label,ids in zip(spec["actions"],labels,strict=True):
            assert tokenizer.encode(text+label,add_special_tokens=False)==prefix+ids
        return prefix

    def batch(prefixes):
        length = max(map(len,prefixes))
        ids = torch.full((len(prefixes),length),tokenizer.pad_token_id,device="cuda",dtype=torch.long)
        mask = torch.zeros_like(ids)
        for j,prefix in enumerate(prefixes):
            ids[j,:len(prefix)] = torch.tensor(prefix,device="cuda")
            mask[j,:len(prefix)] = 1
        last = torch.tensor([len(p)-1 for p in prefixes],device="cuda")
        return ids,mask,last

    inputs = [prepare(r["messages"]) for r in rows]
    assert len({tuple(ids) for ids in inputs})==len(rows)
    size = spec["batch_size"]
    groups = [list(range(i,i+size)) for i in range(0,len(rows),size)]
    input_batches = {tuple(g):batch([inputs[i] for i in g]) for g in groups}
    for ids in by_partner.values():
        assert tuple(ids) in input_batches

    def hidden(tensors):
        ids,mask,last = tensors
        out = base.model(input_ids=ids,attention_mask=mask,use_cache=False).last_hidden_state
        return out[torch.arange(len(ids),device="cuda"),last].float()

    def log_odds(h):
        w = head.weight[tokens].detach().float()
        return h @ (w[0]-w[1])

    def observe():
        with torch.no_grad():
            return torch.cat([log_odds(hidden(input_batches[tuple(g)])) for g in groups]).cpu().tolist()

    def cached_scores(features):
        return torch.cat([log_odds(features[g]) for g in groups]).cpu().tolist()

    with torch.no_grad(),model.disable_adapter():
        features = torch.cat([hidden(input_batches[tuple(g)]) for g in groups])
        frozen = cached_scores(features)
    assert len(frozen)==72
    feature_cpu = features.cpu().numpy().astype(float)
    feature_scale = float(np.median(np.linalg.norm(feature_cpu,axis=1)))
    edit_inputs = feature_cpu/feature_scale
    write(output/"frozen.json",dict(log_odds=frozen,rows=rows,head_tied_on_load=tied))
    np.save(output/"frozen_hidden.npy",feature_cpu.astype(np.float32),allow_pickle=False)
    fixed = {id(p):p._version for n,p in model.named_parameters() if ".lora_" not in n and p is not head.weight}

    def q(counts,row):
        yes,n = counts.get(row["partner"],{}).get(row["style"],[0,0])
        return (yes+1)/(n+2)

    def stage_targets(stage):
        return [q(stage["counts"],r) for r in rows]

    def weight_evidence(name,block,history,phases,**kwargs):
        assert all(len(v)==len(rows) and np.isfinite(v).all() for v in phases.values())
        write(output/f"{name}-{block['id']}-h{history}.json",dict(method=name,block=block["id"],history=history,
              focus=block["focus"],checkpoints=phases,**kwargs))

    steps_per_phase = spec["steps_per_phase"]
    total = len(spec["blocks"])*7*steps_per_phase
    started = time.monotonic()
    status.update(stage="weight-methods",completed_jobs=0,total_jobs=8,
                  optimizer_steps=0,total_optimizer_steps=total,head_tied_on_load=tied)
    write(output/"status.json",status)

    def complete():
        status["completed_jobs"] += 1
        status["experiment_elapsed_seconds"] = time.monotonic()-started
        write(output/"status.json",status)

    def run_readouts():
        for block in spec["blocks"]:
            for h,history in enumerate(block["histories"]):
                phase_counts = history["phases"]
                for method in ("edit_anchored",):
                    cp = {"0":frozen}
                    state = []
                    with torch.no_grad():
                        head.weight.index_copy_(0,tokens,head_start)
                        for stage in phase_counts:
                            active = by_partner[stage["active"]]
                            keep = [i for i in train_ids if i not in active] if method=="edit_anchored" else []
                            current = np.array(cached_scores(features))
                            targets = np.array(stage_targets(stage))[active]
                            residual = np.r_[np.log(targets/(1-targets))-current[active],np.zeros(len(keep))]
                            weights = np.r_[np.ones(len(active)),np.full(len(keep),spec["edit_anchor_weight"])]
                            delta = ridge_edit(edit_inputs[active+keep],residual,weights,spec["ridge_lambda"])/feature_scale
                            change = torch.as_tensor(delta,dtype=torch.float32,device="cuda")*.5
                            values = head.weight[tokens].float() + torch.stack([change,-change])
                            head.weight.index_copy_(0,tokens,values.to(head.weight.dtype))
                            cp[str(stage["turn"])] = cached_scores(features)
                            state.append(dict(turn=stage["turn"],active_rows=len(active),anchor_rows=len(keep),
                                             realized_delta_l2=float((head.weight[tokens].float()-head_start.float()).norm().item())))
                        assert cp["60"] == observe()
                        out = head.weight[tokens].detach().cpu().contiguous()
                        assert not torch.equal(out,head_start.cpu())
                        save_file({"lm_head_selected_rows":out},str(output/f"{method}-{block['id']}-h{h}.safetensors"))
                        head.weight.index_copy_(0,tokens,head_start)
                    weight_evidence(method,block,h,cp,head_rows=labels,parameter_count=out.numel(),edits=state)
                    complete()


    with model.disable_adapter():
        run_readouts()

    regex = r"model\.language_model\.layers\.(0|1|2|3)\.mlp\.down_proj"
    model.add_adapter("early",LoraConfig(r=cfg["rank"],lora_alpha=cfg["alpha"],lora_dropout=0.,bias="none",target_modules=regex))
    model.set_adapter("early")
    model.eval()
    lora = {n:p for n,p in model.named_parameters() if p.requires_grad}
    assert len(lora)==8 and sum(p.numel() for p in lora.values())==188416
    generator = torch.Generator(device="cpu").manual_seed(spec["initial_seed"])
    lora_start = [{},{}]
    for name,p in sorted(lora.items()):
        match = re.search(r"layers\.(\d+)(.*lora_([AB]))\.early\.weight$",name)
        assert match
        old_name = name.replace(f"layers.{match[1]}.",f"layers.{28+int(match[1])}.").replace(".early.",".default.")
        lora_start[0][name] = initial[old_name]
        lora_start[1][name] = (torch.empty_like(initial[old_name]).uniform_(-p.shape[1]**-.5,p.shape[1]**-.5,generator=generator)
                              if match[3]=="A" else torch.zeros_like(initial[old_name]))

    def fit_gradient(method,parameters,starts):
        def install(snapshot):
            with torch.no_grad():
                for name,p in parameters.items():
                    p.grad = None
                    p.copy_(snapshot[name])

        def save_state():
            return {name:p.detach().cpu().contiguous().clone() for name,p in parameters.items()}

        def optimize(stage,optimizer,job):
            ids = by_partner[stage["active"]]
            target = torch.tensor([q(stage["counts"],rows[i]) for i in ids],device="cuda",dtype=torch.float32)
            logs = []
            for i in range(steps_per_phase):
                optimizer.zero_grad(set_to_none=True)
                logits = log_odds(hidden(input_batches[tuple(ids)]))
                loss = F.binary_cross_entropy_with_logits(logits,target)
                assert torch.isfinite(loss)
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_(parameters.values(),cfg["gradient_clip"],error_if_nonfinite=True)
                optimizer.step()
                logs.append([float(loss.item()),float(norm.item())])
                status.update(job=job,turn=stage["turn"],optimizer_steps=status["optimizer_steps"]+1,
                              experiment_elapsed_seconds=time.monotonic()-started)
                if (i+1)%4==0:
                    write(output/"status.json",status)
            return logs

        for index,block in enumerate(spec["blocks"]):
            install(starts[index])
            assert observe()==frozen
            optimizer = torch.optim.AdamW(parameters.values(),lr=spec["learning_rate"],weight_decay=cfg["weight_decay"])
            anchor = block["histories"][0]["phases"][0]
            logs = {"15":optimize(anchor,optimizer,f"{method}-{block['id']}-common")}
            after_anchor = observe()
            anchor_state, optimizer_state = save_state(),deepcopy(optimizer.state_dict())
            for h,history in enumerate(block["histories"]):
                install(anchor_state)
                optimizer.load_state_dict(deepcopy(optimizer_state))
                cp = {"0":frozen,"15":after_anchor}
                records = dict(logs)
                for stage in history["phases"][1:]:
                    turn = str(stage["turn"])
                    records[turn] = optimize(stage,optimizer,f"{method}-{block['id']}-h{h}")
                    cp[turn] = observe()
                saved = save_state()
                assert tensor_hash(saved.items()) != tensor_hash(starts[index].items())
                save_file(saved,str(output/f"{method}-{block['id']}-h{h}.safetensors"))
                weight_evidence(method,block,h,cp,parameter_count=sum(x.numel() for x in parameters.values()),
                                training_steps=records,final_parameter_sha256=tensor_hash(saved.items()))
                complete()
        for p in parameters.values():
            p.grad=None

    ia3,handles = {},[]
    for i in spec["layers"]:
        down = base.model.language_model.layers[i].mlp.down_proj.get_base_layer()
        scale = torch.nn.Parameter(torch.ones(down.in_features,device="cuda",dtype=torch.float32))
        ia3[f"mlp.{i}.scale"] = scale

        def apply_scale(_,args,scale=scale):
            x,*rest = args
            return ((x.float()*scale).to(x.dtype),*rest)

        handles.append(down.register_forward_pre_hook(apply_scale))
    try:
        with model.disable_adapter():
            unity = {name:torch.ones_like(p,device="cpu") for name,p in ia3.items()}
            fit_gradient("ia3",ia3,[unity,unity])
    finally:
        for handle in handles:
            handle.remove()
    assert status["optimizer_steps"]==total
    assert status["completed_jobs"]==8
    assert torch.equal(head.weight[tokens],head_start)
    assert {id(p):p._version for n,p in model.named_parameters() if ".lora_" not in n and p is not head.weight}==fixed
    with model.disable_adapter():
        assert observe()==frozen
    status.update(stage="complete",total_jobs=8,base_restored=True,peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                  experiment_elapsed_seconds=time.monotonic()-started,feature_scale=feature_scale)
    write(output/"status.json",status)
