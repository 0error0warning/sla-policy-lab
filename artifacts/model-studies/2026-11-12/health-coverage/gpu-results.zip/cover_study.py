"""Same-tape health coverage experiment with numerical path measurements."""

import argparse
from hashlib import sha256
from importlib import metadata
import json
import os
from pathlib import Path
import subprocess

import numpy as np

from mechanisms import observe
from protocol import (ARMS, ORDERS, World, policy, prompt, request, returns,
                      reward, sample_action, settle, write)
from run_gpu import Actor, tensor_hash


SEEDS = (62201, 62202, 62203, 62204)
HEALTHS = (300., 90., 15., 10., 6., 2.)


def physical(tape, health):
    rows = []
    for event in tape['trace']:
        before = health
        health, events = settle(health, event['action'], event['accepted'], event['noise'])
        common, parts = reward(before, health, event['action'], event['accepted'], False)
        full, _ = reward(before, health, event['action'], event['accepted'], True)
        keys = ('turn','action','accepted','noise','order','partner','request','frame','task','wording')
        row = {key:event[key] for key in keys if key in event}
        row.update(health_before=before, health_after=health, body_events=events,
                   reward_common=common, reward_body=full, reward_components=parts)
        rows.append(row)
        if health<=0:
            break
    return rows


def lower_start(tape):
    lo, hi = 1., 90.
    assert physical(tape,hi)[-1]['health_after']>1
    for _ in range(60):
        middle = (lo+hi)/2
        if physical(tape,middle)[-1]['health_after']>=1:
            hi = middle
        else:
            lo = middle
    return hi


def state(actor):
    torch = actor.torch
    return dict(cpu_rng=sha256(torch.get_rng_state().numpy().tobytes()).hexdigest(),
                cuda_rng=sha256(torch.cuda.get_rng_state().cpu().numpy().tobytes()).hexdigest(),
                buffers={name:tensor_hash([('buffer',value)])
                         for name,value in actor.model.named_buffers()})


def runtime(actor):
    try:
        device = subprocess.check_output(
            ['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True).strip()
    except (FileNotFoundError,subprocess.CalledProcessError):
        device = 'not recorded'
    torch = actor.torch
    return dict(gpu_driver=device,torch=torch.__version__,cuda=torch.version.cuda,
                cudnn=torch.backends.cudnn.version(),python=os.sys.version,
                versions={name:metadata.version(name) for name in
                          ('transformers','peft','numpy','flash-linear-attention','fla-core','triton')},
                deterministic=torch.are_deterministic_algorithms_enabled(),
                matmul_tf32=torch.backends.cuda.matmul.allow_tf32,
                sdpa_flash=torch.backends.cuda.flash_sdp_enabled(),
                sdpa_math=torch.backends.cuda.math_sdp_enabled(),
                sdpa_memory_efficient=torch.backends.cuda.mem_efficient_sdp_enabled(),
                cpu_threads=torch.get_num_threads(),
                cublas_workspace=os.environ.get('CUBLAS_WORKSPACE_CONFIG'))


def panel():
    rows = [dict(health=h, visible=True, frame=f, order=list(order), partner='P17',
                 request=request(f,4,2)) for h in HEALTHS for f in (0,1) for order in ORDERS]
    rows.extend(dict(health=None,visible=False,frame=f,order=list(order),partner='P17',
                     request=request(f,4,2)) for f in (0,1) for order in ORDERS)
    return rows


def encode(actor, rows):
    return [actor.encode(prompt(r['partner'],r['request'],r['health'] or 300.,
                                r['order'],r['visible'])) for r in rows]


def train(actor, case, tokens, destination):
    from safetensors.torch import save_file
    actor.reset('early')
    reset_state = state(actor)
    reset_parameter_sha256 = tensor_hash(actor.snapshot().items())
    before, _ = observe(actor,[r['input_token_ids'] for r in case['buffer']])
    opt = actor.torch.optim.AdamW(actor.parameters['early'].values(),lr=.0001,weight_decay=0.)
    from run_gpu import optimize
    updates, doses = [], {}
    for dose, epochs in ((8,4),(24,8)):
        updates.append(optimize(actor,opt,case['buffer'],dict(ARMS['body'],epochs=epochs),
                                np.array(case['baseline']),case['seed'],1,lambda **_:None))
        selected, _ = observe(actor,[r['input_token_ids'] for r in case['buffer']])
        scored, _ = observe(actor,tokens)
        doses[str(dose)] = dict(logits=scored.tolist(),training_logits=selected.tolist())
    weights = actor.snapshot()
    save_file(weights,str(destination.with_suffix('.safetensors')))
    result = dict(case,training_before_logits=before.tolist(),updates=updates,doses=doses,
                  adapter_sha256=tensor_hash(weights.items()),reset_state=reset_state,
                  reset_parameter_sha256=reset_parameter_sha256,end_state=state(actor))
    write(destination.with_suffix('.json'),result)
    return result


def run(root):
    output = root/'output'
    output.mkdir(exist_ok=False)
    status = dict(stage='initializing',completed=0,total=8)
    def progress(**values):
        status.update(values)
        write(output/'status.json',status)
    actor = Actor(root,output,progress)
    write(output/'runtime.json',runtime(actor))
    audit_rows = json.loads((root/'audit-panel.json').read_bytes())
    audit_tokens = encode(actor,audit_rows)
    audit = []
    def snapshot(name):
        before = state(actor)
        scores, _ = observe(actor,audit_tokens)
        audit.append(dict(name=name,before=before,after=state(actor),logits=scores.tolist()))
        write(output/'numeric-path.json',audit)
    snapshot('immediate_after_load')
    snapshot('same_batch_repeat')
    write(output/'audit-tokens.json',audit_tokens)
    write(output/'audit-batch-layout.json',[
        dict(indices=list(range(i,min(i+4,len(audit_tokens)))),
             width=max(map(len,audit_tokens[i:i+4])))
        for i in range(0,len(audit_tokens),4)])
    tapes = []
    for index, seed in enumerate(SEEDS):
        world = World(seed,index%2,f'coverage-source-{seed}')
        rows = []
        for item in world.items[:8]:
            tokens = actor.encode(prompt(item['partner'],item['request'],world.health,item['order'],True))
            logits, _ = observe(actor,[tokens])
            action,label,uniform = sample_action(policy(logits)[0],item['order'],seed,item['turn'])
            row = world.step(world.encounter_id(),action)
            row.update(source_logits=logits[0].tolist(),source_tokens=tokens,
                       source_label=label,source_choice_uniform=uniform)
            rows.append(row)
        tapes.append(dict(seed=seed,mapping=index%2,trace=rows))
    write(output/'tapes.json',tapes)
    snapshot('after_source_sampling')
    actor.reset('early')
    snapshot('after_parameter_rng_reset')
    rows = panel()
    tokens = encode(actor,rows)
    initial, _ = observe(actor,tokens)
    write(output/'panel.json',rows)
    write(output/'panel-tokens.json',tokens)
    write(output/'initial.json',initial.tolist())
    calibration = json.loads((root/'calibration-tapes.json').read_bytes())
    references = [returns([r['reward_body'] for r in physical(tape,90.)],.97) for tape in calibration]
    baseline = np.mean(references,axis=0).tolist()
    write(output/'baseline.json',dict(sources=[t['seed'] for t in calibration],
                                    source_returns=[g.tolist() for g in references],baseline=baseline))
    cases = []
    for tape in tapes:
        actor.reset('early')
        prefixes = [actor.encode(prompt(r['partner'],r['request'],300.,r['order'],False))
                    for r in tape['trace']]
        logits, _ = observe(actor,prefixes)
        behavior = policy(logits)
        start = lower_start(tape)
        for regime,health in (('original',90.),('covered',start)):
            buffer = physical(tape,health)
            assert len(buffer)==8 and all(r['health_after']>0 for r in buffer)
            for i,row in enumerate(buffer):
                label = row['order'].index(row['action'])
                row.update(input_token_ids=prefixes[i],label_index=label,
                           old_log_probability=float(np.log(behavior[i,label])))
            case = dict(seed=tape['seed'],mapping=tape['mapping'],regime=regime,
                        coverage_start=start,baseline=baseline,buffer=buffer)
            cases.append(case)
            name = f"{tape['seed']}-{regime}"
            train(actor,case,tokens,output/name)
            status['completed'] += 1
            progress(stage='training',case=name)
    for case in cases[:2]:
        name = f"repeat-{case['seed']}-{case['regime']}"
        train(actor,case,tokens,output/name)
        progress(stage='same_process_repeat',case=name)
    actor.reset('early')
    snapshot('after_all_training_reset')
    actor.verify_base()
    write(output/'audit-panel.json',audit_rows)
    progress(stage='complete',base_unchanged=True,base_sha256=actor.base_hash,
             main_optimizer_steps=192,numeric_repeat_steps=48)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    run(p.parse_args().root)
