"""New process on the same GPU, using exact frozen inputs and a saved case."""
import argparse
import json
from pathlib import Path

from cover_study import encode, runtime, state, train
from mechanisms import observe
from protocol import write
from run_gpu import Actor
from safetensors.torch import load_file


def run(root):
    output = root/'fresh-output'
    output.mkdir(exist_ok=False)
    actor = Actor(root,output,lambda **_:None)
    write(output/'runtime.json',runtime(actor))
    source = root/'output'
    audits = json.loads((source/'audit-tokens.json').read_bytes())
    before = state(actor)
    scores, _ = observe(actor,audits)
    write(output/'frozen.json',dict(logits=scores.tolist(),before=before,after=state(actor)))
    panel = json.loads((source/'panel.json').read_bytes())
    tokens = json.loads((source/'panel-tokens.json').read_bytes())
    assert tokens==encode(actor,panel)
    for regime in ('original','covered'):
        name=f'62201-{regime}'
        actor.install(load_file(str(source/f'{name}.safetensors')))
        logits, _ = observe(actor,tokens)
        write(output/f'{name}-reloaded.json',logits.tolist())
    case = json.loads((source/'62201-original.json').read_bytes())
    spec = {k:case[k] for k in ('seed','mapping','regime','coverage_start','baseline','buffer')}
    train(actor,spec,tokens,output/'retrained-62201-original')
    actor.reset('early')
    actor.verify_base()
    write(output/'status.json',dict(stage='complete',base_unchanged=True,
                                   base_sha256=actor.base_hash,optimizer_steps=24))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    run(p.parse_args().root)
